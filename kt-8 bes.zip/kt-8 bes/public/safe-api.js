class SafeAPI {
    constructor(baseURL) {
        this.baseURL = baseURL;
        // Хранилище для pending запросов (защита от дублирования форм)
        this.pendingRequests = new Map();
        // Флаг обновления токена (чтобы не делать несколько параллельных refresh)
        this.isRefreshing = false;
        this.refreshSubscribers = [];
    }

    // Внутренний метод для выполнения запросов с retry и защитой от повторной отправки
    async _requestWithRetry(url, options, retries = 3) {
        const requestKey = `${options.method || 'GET'}:${url}:${JSON.stringify(options.body || {})}`;
        // Если такой запрос уже выполняется (защита от повторной отправки формы)
        if (this.pendingRequests.has(requestKey)) {
            console.warn('Повторная отправка формы заблокирована');
            return this.pendingRequests.get(requestKey);
        }

        const executeRequest = async (attempt = 1) => {
            try {
                const fetchOptions = {
                    ...options,
                    credentials: 'include', // важно для отправки httpOnly cookies
                    headers: {
                        'Content-Type': 'application/json',
                        ...(options.headers || {})
                    }
                };
                if (options.body) {
                    fetchOptions.body = JSON.stringify(options.body);
                }
                const response = await fetch(`${this.baseURL}${url}`, fetchOptions);
                if (!response.ok) {
                    const errorText = await response.text();
                    let errorMessage;
                    try {
                        const errJson = JSON.parse(errorText);
                        errorMessage = errJson.message || errJson.error || `HTTP ${response.status}`;
                    } catch (e) {
                        errorMessage = errorText || `HTTP ${response.status}`;
                    }
                    const error = new Error(errorMessage);
                    error.status = response.status;
                    throw error;
                }
                // Если ответ пустой (204 No Content)
                if (response.status === 204) {
                    return null;
                }
                return await response.json();
            } catch (err) {
                if (attempt < retries && !err.status) { // retry только при сетевых ошибках (не 4xx/5xx)
                    console.log(`Retry ${attempt}/${retries} for ${url}`);
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                    return executeRequest(attempt + 1);
                }
                throw err;
            }
        };

        const promise = executeRequest();
        this.pendingRequests.set(requestKey, promise);
        try {
            const result = await promise;
            return result;
        } finally {
            // Удаляем из pending после завершения (но не сразу, чтобы защитить от очень быстрых повторных кликов)
            setTimeout(() => this.pendingRequests.delete(requestKey), 500);
        }
    }

    // Метод для подписки на обновление токена (когда несколько запросов ждут refresh)
    _subscribeToRefresh(callback) {
        this.refreshSubscribers.push(callback);
    }

    _onRefreshSuccess() {
        this.refreshSubscribers.forEach(cb => cb());
        this.refreshSubscribers = [];
    }

    // Обновление access токена (предполагается, что сервер обновляет httpOnly cookie)
    async refreshToken() {
        if (this.isRefreshing) {
            // Если уже идет обновление, возвращаем промис, который разрешится после его завершения
            return new Promise((resolve, reject) => {
                this._subscribeToRefresh(resolve);
                this._subscribeToRefresh(reject);
            });
        }
        this.isRefreshing = true;
        try {
            // Запрос на /refresh – сервер установит новую access cookie (httpOnly)
            await this._requestWithRetry('/refresh', { method: 'POST' }, 1);
            this._onRefreshSuccess();
            this.isRefreshing = false;
            return true;
        } catch (err) {
            this.isRefreshing = false;
            throw err;
        }
    }

    // Безопасная регистрация
    async register(userData) {
        if (!userData.name || !userData.email || !userData.password) {
            throw new Error('Имя, email и пароль обязательны');
        }
        return this._requestWithRetry('/register', {
            method: 'POST',
            body: userData
        });
    }

    // Вход – сервер устанавливает httpOnly cookie
    async login(credentials) {
        if (!credentials.email || !credentials.password) {
            throw new Error('Email и пароль обязательны');
        }
        return this._requestWithRetry('/login', {
            method: 'POST',
            body: credentials
        });
    }

    // Получение профиля с автоматическим обновлением токена при 401
    async getProfile() {
        try {
            return await this._requestWithRetry('/profile', { method: 'GET' });
        } catch (err) {
            if (err.status === 401) {
                // Пробуем обновить токен
                try {
                    await this.refreshToken();
                    // Повторяем запрос после обновления
                    return await this._requestWithRetry('/profile', { method: 'GET' });
                } catch (refreshErr) {
                    // Если обновить не удалось – выбрасываем ошибку 401
                    throw new Error('Unauthorized: сессия истекла');
                }
            }
            throw err;
        }
    }

    // Безопасный выход – сервер удаляет httpOnly cookies
    async logout() {
        try {
            await this._requestWithRetry('/logout', { method: 'POST' });
        } catch (err) {
            // Даже если ошибка, чистим локальное состояние (но cookies удалит сервер)
            console.warn('Ошибка при выходе:', err);
        }
    }
}