const express = require('express');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const fs = require('fs');
const https = require('https');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cookieParser());

// Раздача статических файлов из папки public
app.use(express.static(path.join(__dirname, 'public')));

// --- Простая "база данных" в памяти ---
const users = new Map();        // email -> user object
const refreshTokens = new Map(); // refreshToken -> email

function hashPassword(pwd) {
    return crypto.createHash('sha256').update(pwd).digest('hex');
}

function generateAccessToken() {
    return crypto.randomBytes(32).toString('hex');
}

function generateRefreshToken() {
    return crypto.randomBytes(64).toString('hex');
}

// Middleware аутентификации
function authenticate(req, res, next) {
    const accessToken = req.cookies.access_token;
    if (!accessToken) {
        return res.status(401).json({ error: 'Не авторизован' });
    }
    let authenticatedEmail = null;
    for (let [email, user] of users.entries()) {
        if (user.accessToken === accessToken) {
            authenticatedEmail = email;
            break;
        }
    }
    if (!authenticatedEmail) {
        return res.status(401).json({ error: 'Недействительный токен' });
    }
    req.userEmail = authenticatedEmail;
    next();
}

// Регистрация
app.post('/register', (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
        return res.status(400).json({ error: 'Все поля обязательны' });
    }
    if (users.has(email)) {
        return res.status(409).json({ error: 'Пользователь уже существует' });
    }
    const id = crypto.randomUUID();
    const passwordHash = hashPassword(password);
    const user = { id, name, email, passwordHash };
    users.set(email, user);
    res.status(201).json({ message: 'Регистрация успешна' });
});

// Логин
app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.get(email);
    if (!user || user.passwordHash !== hashPassword(password)) {
        return res.status(401).json({ error: 'Неверные учётные данные' });
    }
    const accessToken = generateAccessToken();
    const refreshToken = generateRefreshToken();
    user.accessToken = accessToken;
    refreshTokens.set(refreshToken, email);
    res.cookie('access_token', accessToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000
    });
    res.cookie('refresh_token', refreshToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'strict',
        maxAge: 7 * 24 * 60 * 60 * 1000
    });
    res.json({ message: 'Вход выполнен' });
});

// Обновление access токена
app.post('/refresh', (req, res) => {
    const refreshToken = req.cookies.refresh_token;
    if (!refreshToken) {
        return res.status(401).json({ error: 'Refresh token отсутствует' });
    }
    const email = refreshTokens.get(refreshToken);
    if (!email) {
        return res.status(403).json({ error: 'Недействительный refresh token' });
    }
    const user = users.get(email);
    if (!user) {
        return res.status(403).json({ error: 'Пользователь не найден' });
    }
    const newAccessToken = generateAccessToken();
    user.accessToken = newAccessToken;
    res.cookie('access_token', newAccessToken, {
        httpOnly: true,
        secure: true,
        sameSite: 'strict',
        maxAge: 15 * 60 * 1000
    });
    res.json({ message: 'Токен обновлён' });
});

// Получение профиля
app.get('/profile', authenticate, (req, res) => {
    const user = users.get(req.userEmail);
    res.json({
        id: user.id,
        name: user.name,
        email: user.email
    });
});

// Выход
app.post('/logout', (req, res) => {
    const refreshToken = req.cookies.refresh_token;
    if (refreshToken) {
        refreshTokens.delete(refreshToken);
    }
    res.clearCookie('access_token', { httpOnly: true, secure: true, sameSite: 'strict' });
    res.clearCookie('refresh_token', { httpOnly: true, secure: true, sameSite: 'strict' });
    res.json({ message: 'Выход выполнен' });
});

// --- HTTPS: загрузка сертификатов ---
let httpsOptions;
try {
    httpsOptions = {
        key: fs.readFileSync(path.join(__dirname, 'key.pem')),
        cert: fs.readFileSync(path.join(__dirname, 'cert.pem'))
    };
} catch (err) {
    console.error('❌ Ошибка: не найдены файлы cert.pem или key.pem');
    console.error('Сгенерируйте самоподписанный сертификат командой:');
    console.error('openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes');
    process.exit(1);
}

https.createServer(httpsOptions, app).listen(3000, () => {
    console.log('✅ HTTPS сервер запущен на https://localhost:3000');
    console.log('Примите предупреждение о сертификате в браузере.');
});